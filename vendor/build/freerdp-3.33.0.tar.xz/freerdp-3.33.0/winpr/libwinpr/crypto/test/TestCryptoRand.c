
#include <winpr/crt.h>
#include <winpr/print.h>
#include <winpr/crypto.h>

int TestCryptoRand(int argc, char* argv[])
{
	char* str = nullptr;
	BYTE rnd[16] = WINPR_C_ARRAY_INIT;

	WINPR_UNUSED(argc);
	WINPR_UNUSED(argv);

	if (winpr_RAND(rnd, sizeof(rnd)) < 0)
		return -1;

	str = winpr_BinToHexString(rnd, sizeof(rnd), FALSE);
	// (void)fprintf(stderr, "Rand: %s\n", str);
	free(str);

	if (memcmp(rnd, "\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00", 16) == 0)
	{
		return -1;
	}

	return 0;
}
